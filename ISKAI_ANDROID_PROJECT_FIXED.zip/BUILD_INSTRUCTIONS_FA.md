# راهنمای ساخت APK — افسانه ایسکای

> **وضعیت صادقانه:** در محیطی که این پروژه اصلاح شد Android SDK، Gradle، `javac` و اینترنت وجود نداشت؛ بنابراین **APK ساخته نشد** و فایل `Iskai_Emerald_Android.apk` تحویل داده نمی‌شود. پروژه آماده‌ی ساخت است، اما ساخت آن هنوز هرگز اجرا نشده است.

## روش ۱ (ساده‌ترین، بدون نصب چیزی روی کامپیوتر): GitHub Actions
1. یک مخزن (repository) خصوصی در GitHub بسازید و محتوای پوشه‌ی `ISKAI_Android_Project` را در ریشه‌ی آن آپلود کنید (شامل پوشه‌ی مخفی `.github`).
2. تب **Actions ← Build Iskai APK ← Run workflow** را بزنید.
3. پس از پایان (چند دقیقه)، از بخش **Artifacts** فایل‌های `Iskai_Emerald_Android.apk` (امضا: debug) و `APK_SHA256.txt` را دانلود کنید.
(workflow خودش Three.js r128 را دانلود و داخل APK قرار می‌دهد.)

## روش ۲: Android Studio
1. `bash scripts/fetch_three.sh` (یا دانلود دستی `https://cdn.jsdelivr.net/npm/three@0.128.0/build/three.min.js` و ذخیره با نام `three.min.js` در `app/src/main/assets/`).
2. پروژه را باز کنید ← Sync ← **Build ▸ Build APK(s)**. خروجی: `app/build/outputs/apk/debug/app-debug.apk`.

## روش ۳: خط فرمان (JDK 17 + Android SDK + Gradle 8.9)
```
bash scripts/fetch_three.sh
gradle assembleDebug        # یا assembleRelease
```
اگر `three.min.js` وجود نداشته باشد، ساخت عمداً با پیام خطا متوقف می‌شود (تا APK با صفحه‌ی خالی ساخته نشود).

## نصب روی گوشی
فایل APK را منتقل کنید ← «نصب از منابع ناشناس» را برای مرورگر/مدیر فایل مجاز کنید ← نصب. (امضای debug؛ برای انتشار در فروشگاه باید کلید release بسازید.)
## دیدن خطاهای جاوااسکریپت: `adb logcat -s IskaiGame`
