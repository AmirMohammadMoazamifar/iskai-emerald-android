APK ساخته نشده است. به BUILD_INSTRUCTIONS_FA.md و TEST_REPORT_FA.md (کنار این پوشه) مراجعه کنید.
