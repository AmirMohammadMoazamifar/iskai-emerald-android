package com.iskai.emerald;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String TAG = "IskaiGame";
    private static final String URL = "file:///android_asset/index.html";
    private WebView webView;
    private long lastBack = 0;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createWebView();
        webView.loadUrl(URL);   // game progress lives in localStorage (DOM storage), which persists across launches
    }

    private void createWebView() {
        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient() {
            // If the WebView renderer is killed (e.g. low memory) rebuild it instead of crashing the whole app.
            @Override public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                Log.e(TAG, "render process gone, crashed=" + d.didCrash());
                runOnUiThread(() -> { ViewGroup p = (ViewGroup) v.getParent(); if (p != null) p.removeView(v); v.destroy(); createWebView(); webView.loadUrl(URL); });
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(ConsoleMessage m) {   // JS errors: adb logcat -s IskaiGame
                Log.println(m.messageLevel() == ConsoleMessage.MessageLevel.ERROR ? Log.ERROR : Log.INFO, TAG,
                    m.message() + " (" + m.sourceId() + ":" + m.lineNumber() + ")");
                return true;
            }
        });
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setBackgroundColor(0xFF05040A);
        setContentView(webView);
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }
    @Override public void onWindowFocusChanged(boolean hasFocus) { super.onWindowFocusChanged(hasFocus); if (hasFocus) immersive(); }

    @Override protected void onPause() {
        if (webView != null) { webView.evaluateJavascript("window.dispatchEvent(new Event('pagehide'))", null); webView.onPause(); }
        super.onPause();
    }
    @Override protected void onResume() { super.onResume(); if (webView != null) webView.onResume(); immersive(); }

    // Back button must not kill the game by accident: press twice to exit.
    @Override public void onBackPressed() {
        long now = System.currentTimeMillis();
        if (now - lastBack < 2000) super.onBackPressed();
        else { lastBack = now; Toast.makeText(this, "برای خروج دوباره بزنید", Toast.LENGTH_SHORT).show(); }
    }
    @Override protected void onDestroy() { if (webView != null) { webView.destroy(); webView = null; } super.onDestroy(); }
}
