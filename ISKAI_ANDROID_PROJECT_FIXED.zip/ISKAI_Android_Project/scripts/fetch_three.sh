#!/usr/bin/env bash
# Downloads the EXACT Three.js version the game was written for (r128, MIT license) into the APK assets.
set -euo pipefail
OUT="$(dirname "$0")/../app/src/main/assets/three.min.js"
curl -fsSL https://cdn.jsdelivr.net/npm/three@0.128.0/build/three.min.js -o "$OUT"
test "$(wc -c < "$OUT")" -gt 400000 || { echo "download looks wrong"; exit 1; }
echo "OK: $(wc -c < "$OUT") bytes -> $OUT"
